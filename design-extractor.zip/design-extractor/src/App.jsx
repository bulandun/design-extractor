import { useState, useCallback, useRef } from 'react'

const TAB_LABELS = ['Layout', 'Tokens', 'Components', 'Combined']
const PHASE_KEYS = ['layout', 'tokens', 'components']

function parseJSON(raw) {
  let t = raw.trim().replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '')
  const s = t.search(/[\{\[]/)
  const e = Math.max(t.lastIndexOf('}'), t.lastIndexOf(']'))
  if (s !== -1 && e !== -1) t = t.substring(s, e + 1)
  t = t.replace(/,(\s*[}\]])/g, '$1')
  return JSON.parse(t)
}

export default function App() {
  const [imgData, setImgData] = useState(null)
  const [imgMediaType, setImgMediaType] = useState('image/png')
  const [imgName, setImgName] = useState('')
  const [results, setResults] = useState([null, null, null, null])
  const [activeTab, setActiveTab] = useState(0)
  const [running, setRunning] = useState(false)
  const [status, setStatus] = useState({ msg: 'Ready', state: '' })
  const [error, setError] = useState('')
  const [progress, setProgress] = useState(0)
  const [dragging, setDragging] = useState(false)
  const fileRef = useRef()

  const setImage = (data, mt, name) => {
    setImgData(data)
    setImgMediaType(mt)
    setImgName(name)
    setError('')
    setStatus({ msg: 'Image loaded — ready to extract', state: 'ready' })
  }

  const handleFile = (file) => {
    if (!file) return
    const reader = new FileReader()
    if (file.type === 'application/pdf') {
      reader.onload = (e) => convertPdf(e.target.result)
      reader.readAsDataURL(file)
    } else {
      reader.onload = (e) => {
        const mt = file.type || 'image/png'
        setImage(e.target.result.split(',')[1], mt, file.name)
      }
      reader.readAsDataURL(file)
    }
  }

  const convertPdf = async (pdfDataUrl) => {
    setStatus({ msg: 'Converting PDF…', state: 'running' })
    try {
      if (!window.pdfjsLib) {
        await new Promise((res, rej) => {
          const s = document.createElement('script')
          s.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'
          s.onload = res; s.onerror = rej
          document.head.appendChild(s)
        })
        window.pdfjsLib.GlobalWorkerOptions.workerSrc =
          'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'
      }
      const b64 = pdfDataUrl.split(',')[1]
      const bin = atob(b64)
      const bytes = new Uint8Array(bin.length)
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i)
      const pdf = await window.pdfjsLib.getDocument({ data: bytes }).promise
      const page = await pdf.getPage(1)
      const vp = page.getViewport({ scale: 2 })
      const canvas = document.createElement('canvas')
      canvas.width = vp.width; canvas.height = vp.height
      await page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise
      const dataUrl = canvas.toDataURL('image/png')
      setImage(dataUrl.split(',')[1], 'image/png', 'PDF page 1')
    } catch (err) {
      setError('PDF conversion failed: ' + err.message + '. Try exporting as PNG.')
      setStatus({ msg: 'Error', state: 'error' })
    }
  }

  const runExtraction = async () => {
    if (!imgData || running) return
    setRunning(true)
    setError('')
    setProgress(0)
    const newResults = [null, null, null, null]
    setResults([...newResults])

    for (let i = 0; i < 3; i++) {
      setActiveTab(i)
      setStatus({ msg: `Phase ${i + 1}/4: Extracting ${TAB_LABELS[i].toLowerCase()}…`, state: 'running' })
      setProgress((i / 4) * 100)
      try {
        const res = await fetch('/api/extract', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phase: PHASE_KEYS[i], imageData: imgData, mediaType: imgMediaType })
        })
        if (!res.ok) {
          const err = await res.json().catch(() => ({}))
          throw new Error(err.error || 'Server error ' + res.status)
        }
        newResults[i] = await res.json()
        setResults([...newResults])
      } catch (err) {
        setError(`Phase ${i + 1} failed: ${err.message}`)
        setStatus({ msg: 'Failed', state: 'error' })
        setRunning(false)
        return
      }
    }

    // Build combined
    setStatus({ msg: 'Building combined file…', state: 'running' })
    setProgress(90)
    newResults[3] = {
      meta: { generator: 'Design System Extractor', timestamp: new Date().toISOString(), version: '1.0' },
      ...(newResults[0] || {}),
      ...(newResults[1] || {}),
      ...(newResults[2] || {})
    }
    setResults([...newResults])
    setActiveTab(3)
    setProgress(100)
    setStatus({ msg: 'All 4 phases complete', state: 'done' })
    setRunning(false)
  }

  const download = (obj, name) => {
    const blob = new Blob([JSON.stringify(obj, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = name; a.click()
    URL.revokeObjectURL(url)
  }

  const onDrop = useCallback((e) => {
    e.preventDefault(); setDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) handleFile(file)
  }, [])

  const onPaste = useCallback((e) => {
    const item = [...(e.clipboardData.items || [])].find(i => i.type.startsWith('image/'))
    if (item) handleFile(item.getAsFile())
  }, [])

  const tabDone = (i) => results[i] !== null
  const allDone = results[3] !== null

  return (
    <div style={styles.root} onPaste={onPaste}>
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.headerLeft}>
          <span style={styles.logo}>DSX</span>
          <span style={styles.headerTitle}>Design System Extractor</span>
        </div>
        <div style={styles.headerRight}>
          {allDone && (
            <button style={styles.btnAccent} onClick={() => download(results[3], 'design-system.json')}>
              ↓ Download JSON
            </button>
          )}
        </div>
      </div>

      {/* Progress bar */}
      <div style={styles.progressTrack}>
        <div style={{ ...styles.progressBar, width: progress + '%', opacity: running ? 1 : (progress === 100 ? 0.4 : 0) }} />
      </div>

      <div style={styles.body}>
        {/* Left panel */}
        <div style={styles.leftPanel}>
          <div style={styles.panelHead}>
            <span style={styles.panelLabel}>Input</span>
            {imgData && <button style={styles.btnGhost} onClick={() => { setImgData(null); setResults([null,null,null,null]); setStatus({ msg: 'Ready', state: '' }); setProgress(0); setError(''); }}>Clear</button>}
          </div>

          {/* Upload zone */}
          <div
            style={{ ...styles.uploadZone, ...(dragging ? styles.uploadZoneDrag : {}), ...(imgData ? styles.uploadZoneHasImg : {}) }}
            onClick={() => !imgData && fileRef.current.click()}
            onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
          >
            {imgData ? (
              <img src={`data:${imgMediaType};base64,${imgData}`} alt="preview" style={styles.previewImg} />
            ) : (
              <>
                <div style={styles.uploadIcon}>+</div>
                <p style={styles.uploadLabel}>Drop image or PDF here<br />or click to upload</p>
                <p style={styles.uploadSub}>PNG · JPG · PDF · or paste with Ctrl+V</p>
              </>
            )}
          </div>
          <input ref={fileRef} type="file" accept="image/*,.pdf" style={{ display: 'none' }} onChange={(e) => handleFile(e.target.files[0])} />

          {/* File name */}
          {imgName && <div style={styles.fileName}>{imgName}</div>}

          {/* Extract button */}
          <div style={styles.actionRow}>
            <button
              style={{ ...styles.btnPrimary, ...((!imgData || running) ? styles.btnDisabled : {}) }}
              onClick={runExtraction}
              disabled={!imgData || running}
            >
              {running ? <span style={styles.spinner}>⟳</span> : '◆'}&nbsp;
              {running ? status.msg : 'Extract all phases'}
            </button>
          </div>

          {/* Phase checklist */}
          <div style={styles.checklist}>
            {TAB_LABELS.map((label, i) => (
              <div key={i} style={styles.checkItem}>
                <span style={{ ...styles.checkDot, ...(tabDone(i) ? styles.checkDotDone : running && activeTab === i ? styles.checkDotActive : {}) }}>
                  {tabDone(i) ? '✓' : running && activeTab === i ? '…' : String(i + 1)}
                </span>
                <span style={{ color: tabDone(i) ? 'var(--success, #4ade80)' : running && activeTab === i ? '#fff' : '#666' }}>
                  Phase {i + 1}: {label}
                </span>
              </div>
            ))}
          </div>

          {error && <div style={styles.errorBox}>{error}</div>}
        </div>

        {/* Right panel */}
        <div style={styles.rightPanel}>
          <div style={styles.tabs}>
            {TAB_LABELS.map((label, i) => (
              <button
                key={i}
                style={{ ...styles.tab, ...(activeTab === i ? styles.tabActive : {}), ...(tabDone(i) ? styles.tabDone : {}) }}
                onClick={() => setActiveTab(i)}
              >
                {label}{tabDone(i) ? ' ✓' : ''}
              </button>
            ))}
            {allDone && (
              <button
                style={{ ...styles.btnGhost, marginLeft: 'auto', marginRight: '12px', alignSelf: 'center', fontSize: '11px' }}
                onClick={() => download(results[activeTab], ['layout','tokens','components','combined'][activeTab] + '.json')}
              >
                ↓ tab
              </button>
            )}
          </div>

          <div style={styles.outputArea}>
            {results[activeTab] ? (
              <pre style={styles.pre}>{JSON.stringify(results[activeTab], null, 2)}</pre>
            ) : (
              <div style={styles.placeholder}>
                {running && activeTab === Math.min(activeTab, 2) ? (
                  <p style={styles.placeholderText}><span style={styles.spinner}>⟳</span> {status.msg}</p>
                ) : (
                  <p style={styles.placeholderText}>
                    {imgData ? 'Click "Extract all phases" to analyse your design.' : 'Upload a design image or PDF to get started.'}
                  </p>
                )}
              </div>
            )}
          </div>

          <div style={styles.statusBar}>
            <span style={{ ...styles.statusDot, background: status.state === 'done' ? '#4ade80' : status.state === 'error' ? '#f87171' : status.state === 'running' ? '#e8ff47' : '#444' }} />
            <span style={{ color: '#666', fontSize: '11px' }}>{status.msg}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

const styles = {
  root: { display: 'flex', flexDirection: 'column', height: '100vh', background: '#0f0f0f', color: '#f0f0f0', fontFamily: "'Inter', system-ui, sans-serif", fontSize: '13px' },
  header: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 20px', height: '48px', borderBottom: '1px solid rgba(255,255,255,0.06)', flexShrink: 0 },
  headerLeft: { display: 'flex', alignItems: 'center', gap: '10px' },
  logo: { fontFamily: 'monospace', fontSize: '13px', fontWeight: 700, background: '#e8ff47', color: '#0f0f0f', padding: '2px 6px', borderRadius: '4px', letterSpacing: '0.05em' },
  headerTitle: { fontSize: '13px', color: '#888' },
  headerRight: { display: 'flex', gap: '8px' },
  progressTrack: { height: '2px', background: 'rgba(255,255,255,0.05)', flexShrink: 0 },
  progressBar: { height: '100%', background: '#e8ff47', transition: 'width 0.4s ease', borderRadius: '1px' },
  body: { display: 'grid', gridTemplateColumns: '320px 1fr', flex: 1, overflow: 'hidden' },
  leftPanel: { display: 'flex', flexDirection: 'column', borderRight: '1px solid rgba(255,255,255,0.06)', overflow: 'hidden' },
  rightPanel: { display: 'flex', flexDirection: 'column', overflow: 'hidden' },
  panelHead: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px', borderBottom: '1px solid rgba(255,255,255,0.06)' },
  panelLabel: { fontSize: '11px', fontWeight: 600, color: '#555', textTransform: 'uppercase', letterSpacing: '0.08em' },
  uploadZone: { flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '8px', padding: '24px', cursor: 'pointer', transition: 'background 0.15s', minHeight: '160px', border: '1px dashed rgba(255,255,255,0.1)', margin: '12px', borderRadius: '8px' },
  uploadZoneDrag: { background: 'rgba(232,255,71,0.05)', borderColor: '#e8ff47' },
  uploadZoneHasImg: { cursor: 'default', padding: '8px', border: '1px solid rgba(255,255,255,0.08)' },
  uploadIcon: { width: '32px', height: '32px', border: '1px dashed rgba(255,255,255,0.2)', borderRadius: '6px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#444', fontSize: '18px' },
  uploadLabel: { fontSize: '13px', color: '#555', textAlign: 'center', lineHeight: 1.6 },
  uploadSub: { fontSize: '11px', color: '#333' },
  previewImg: { width: '100%', maxHeight: '220px', objectFit: 'contain', borderRadius: '4px' },
  fileName: { fontSize: '11px', color: '#444', padding: '4px 16px 0', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' },
  actionRow: { padding: '12px 16px' },
  checklist: { padding: '4px 16px 12px', display: 'flex', flexDirection: 'column', gap: '6px' },
  checkItem: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12px', color: '#555' },
  checkDot: { width: '18px', height: '18px', borderRadius: '50%', background: '#1a1a1a', border: '1px solid #2a2a2a', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '10px', fontWeight: 600, color: '#555', flexShrink: 0 },
  checkDotDone: { background: 'rgba(74,222,128,0.15)', border: '1px solid #4ade80', color: '#4ade80' },
  checkDotActive: { background: 'rgba(232,255,71,0.15)', border: '1px solid #e8ff47', color: '#e8ff47' },
  errorBox: { margin: '0 16px 12px', padding: '10px 12px', background: 'rgba(248,113,113,0.1)', border: '1px solid rgba(248,113,113,0.3)', color: '#f87171', borderRadius: '6px', fontSize: '12px', lineHeight: 1.5 },
  tabs: { display: 'flex', alignItems: 'center', borderBottom: '1px solid rgba(255,255,255,0.06)', flexShrink: 0 },
  tab: { padding: '10px 14px', fontSize: '12px', cursor: 'pointer', border: 'none', background: 'transparent', color: '#555', borderBottom: '2px solid transparent', transition: 'all 0.12s', fontFamily: 'inherit' },
  tabActive: { color: '#f0f0f0', borderBottomColor: '#e8ff47' },
  tabDone: { color: '#4ade80' },
  outputArea: { flex: 1, overflow: 'auto', background: '#0a0a0a' },
  pre: { padding: '16px', fontFamily: "'SF Mono','Fira Code',monospace", fontSize: '11.5px', lineHeight: 1.6, color: '#ccc', whiteSpace: 'pre-wrap', wordBreak: 'break-word', animation: 'fadeIn 0.2s ease' },
  placeholder: { display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', minHeight: '200px' },
  placeholderText: { fontSize: '13px', color: '#333', textAlign: 'center', lineHeight: 1.7 },
  statusBar: { display: 'flex', alignItems: 'center', gap: '8px', padding: '8px 16px', borderTop: '1px solid rgba(255,255,255,0.06)', flexShrink: 0 },
  statusDot: { width: '6px', height: '6px', borderRadius: '50%', flexShrink: 0 },
  spinner: { display: 'inline-block', animation: 'spin 1s linear infinite' },
  btnPrimary: { width: '100%', padding: '9px 16px', background: '#e8ff47', color: '#0f0f0f', border: 'none', borderRadius: '6px', fontWeight: 600, fontSize: '13px', cursor: 'pointer', fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' },
  btnDisabled: { opacity: 0.35, cursor: 'not-allowed' },
  btnGhost: { padding: '5px 10px', background: 'transparent', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '5px', color: '#888', fontSize: '12px', cursor: 'pointer', fontFamily: 'inherit' },
  btnAccent: { padding: '7px 14px', background: 'rgba(232,255,71,0.1)', border: '1px solid rgba(232,255,71,0.3)', borderRadius: '6px', color: '#e8ff47', fontSize: '12px', cursor: 'pointer', fontFamily: 'inherit', fontWeight: 500 },
}
