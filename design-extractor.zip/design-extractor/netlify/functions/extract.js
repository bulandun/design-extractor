// Netlify Functions version of the same proxy
// Automatically used when deployed to Netlify via netlify.toml redirect

const PHASES = {
  layout: {
    system: `You are a layout analysis engine. Return ONLY a raw JSON object — no markdown fences, no explanation. Schema:
{"layout":{"pageType":string,"sections":[{"id":string,"type":"navigation"|"hero"|"feature-grid"|"content"|"cta"|"footer"|"other","label":string,"columns":number,"elements":["headline"|"text"|"image"|"button"|"link"|"logo"|"divider"|"icon"|"list"|"form"],"hierarchy":"primary"|"secondary"|"tertiary","alignment":"left"|"center"|"right","estimatedHeightPercent":number}],"gridSystem":{"columns":number,"gutter":string},"responsiveNotes":string}}`,
    user: 'Analyze this design and return the layout structure JSON. Raw JSON only, no fences.'
  },
  tokens: {
    system: `You are a design token extractor. Return ONLY a raw JSON object — no markdown fences, no explanation. Schema:
{"design_tokens":{"colors":{"background":string,"foreground":string,"primary":string,"secondary":string,"accent":string,"muted":string,"border":string,"allColors":[{"hex":string,"usage":string,"frequency":"primary"|"secondary"|"rare"}]},"typography":{"fontFamilies":[{"name":string,"category":"serif"|"sans-serif"|"monospace"|"display","usage":string}],"scale":[{"role":string,"sizePx":number,"weight":number,"lineHeight":number,"letterSpacingPx":number}]},"spacing":{"basePx":number,"scale":[number],"pagePaddingPx":number,"sectionGapPx":number,"elementGapPx":number,"containerMaxWidthPx":number},"borders":{"radiusPx":[number],"widthPx":number,"color":string},"shadows":[{"usage":string,"css":string}]}}`,
    user: 'Extract all design tokens from this design. Raw JSON only, no fences.'
  },
  components: {
    system: `You are a UI component mapper. Return ONLY a raw JSON object — no markdown fences, no explanation. Schema:
{"components":{"navigation":{"type":string,"items":[string],"hasLogo":boolean,"hasCTA":boolean},"hero":{"layout":string,"elements":[string],"hasMedia":boolean},"cards":[{"variant":string,"elements":[string],"count":number}],"buttons":[{"variant":"primary"|"secondary"|"ghost"|"text-link","label":string,"context":string}],"typography":[{"component":string,"tag":string,"usage":string}],"forms":[{"fields":[string],"cta":string}],"footer":{"columns":number,"elements":[string]},"custom":[{"name":string,"description":string,"elements":[string]}]}}`,
    user: 'Map all UI components in this design. Raw JSON only, no fences.'
  }
}

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  }

  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' }
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) }

  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) return { statusCode: 500, headers, body: JSON.stringify({ error: 'ANTHROPIC_API_KEY not set' }) }

  try {
    const { phase, imageData, mediaType } = JSON.parse(event.body)
    const p = PHASES[phase]
    if (!p) return { statusCode: 400, headers, body: JSON.stringify({ error: 'Unknown phase' }) }

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 4096,
        system: p.system,
        messages: [{ role: 'user', content: [
          { type: 'image', source: { type: 'base64', media_type: mediaType || 'image/png', data: imageData } },
          { type: 'text', text: p.user }
        ]}]
      })
    })

    if (!response.ok) {
      const err = await response.json().catch(() => ({}))
      return { statusCode: response.status, headers, body: JSON.stringify({ error: err.error?.message || 'API error' }) }
    }

    const data = await response.json()
    let text = data.content[0].text.trim().replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '')
    const s = text.search(/[\{\[]/), e = Math.max(text.lastIndexOf('}'), text.lastIndexOf(']'))
    if (s !== -1 && e !== -1) text = text.substring(s, e + 1)
    text = text.replace(/,(\s*[}\]])/g, '$1')
    const parsed = JSON.parse(text)

    return { statusCode: 200, headers, body: JSON.stringify(parsed) }
  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) }
  }
}
