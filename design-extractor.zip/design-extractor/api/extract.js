export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')

  if (req.method === 'OPTIONS') return res.status(200).end()
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })

  const apiKey = process.env.ANTHROPIC_API_KEY
  if (!apiKey) return res.status(500).json({ error: 'ANTHROPIC_API_KEY not configured on server.' })

  try {
    const { phase, imageData, mediaType } = req.body

    const phases = {
      layout: {
        system: `You are a layout analysis engine. Return ONLY a raw JSON object — no markdown fences, no explanation. Schema:
{"layout":{"pageType":string,"sections":[{"id":string,"type":"navigation"|"hero"|"feature-grid"|"content"|"cta"|"footer"|"other","label":string,"columns":number,"elements":["headline"|"text"|"image"|"button"|"link"|"logo"|"divider"|"icon"|"list"|"form"],"hierarchy":"primary"|"secondary"|"tertiary","alignment":"left"|"center"|"right","estimatedHeightPercent":number}],"gridSystem":{"columns":number,"gutter":string},"responsiveNotes":string}}`,
        user: 'Analyze this design and return the layout structure JSON. Raw JSON only, no fences.'
      },
      tokens: {
        system: `You are a design token extractor. Return ONLY a raw JSON object — no markdown fences, no explanation. Schema:
{"design_tokens":{"colors":{"background":string,"foreground":string,"primary":string,"secondary":string,"accent":string,"muted":string,"border":string,"allColors":[{"hex":string,"usage":string,"frequency":"primary"|"secondary"|"rare"}]},"typography":{"fontFamilies":[{"name":string,"category":"serif"|"sans-serif"|"monospace"|"display","usage":string}],"scale":[{"role":string,"sizePx":number,"weight":number,"lineHeight":number,"letterSpacingPx":number}]},"spacing":{"basePx":number,"scale":[number],"pagePaddingPx":number,"sectionGapPx":number,"elementGapPx":number,"containerMaxWidthPx":number},"borders":{"radiusPx":[number],"widthPx":number,"color":string},"shadows":[{"usage":string,"css":string}]}}`,
        user: 'Extract all design tokens from this design. Raw JSON only, no fences.'
      },
      components: {
        system: `You are a UI component mapper. Return ONLY a raw JSON object — no markdown fences, no explanation. Schema:
{"components":{"navigation":{"type":string,"items":[string],"hasLogo":boolean,"hasCTA":boolean},"hero":{"layout":string,"elements":[string],"hasMedia":boolean},"cards":[{"variant":string,"elements":[string],"count":number}],"buttons":[{"variant":"primary"|"secondary"|"ghost"|"text-link","label":string,"context":string}],"typography":[{"component":string,"tag":string,"usage":string}],"forms":[{"fields":[string],"cta":string}],"footer":{"columns":number,"elements":[string]},"custom":[{"name":string,"description":string,"elements":[string]}]}}`,
        user: 'Map all UI components in this design. Raw JSON only, no fences.'
      }
    }

    const p = phases[phase]
    if (!p) return res.status(400).json({ error: 'Unknown phase: ' + phase })

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 4096,
        system: p.system,
        messages: [{
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: mediaType || 'image/png', data: imageData } },
            { type: 'text', text: p.user }
          ]
        }]
      })
    })

    if (!response.ok) {
      const err = await response.json().catch(() => ({}))
      return res.status(response.status).json({ error: err.error?.message || 'Anthropic API error ' + response.status })
    }

    const data = await response.json()
    const raw = data.content[0].text

    // Parse JSON from response
    let text = raw.trim().replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '')
    const start = text.search(/[\{\[]/)
    const end = Math.max(text.lastIndexOf('}'), text.lastIndexOf(']'))
    if (start !== -1 && end !== -1) text = text.substring(start, end + 1)
    text = text.replace(/,(\s*[}\]])/g, '$1')

    const parsed = JSON.parse(text)
    return res.status(200).json(parsed)

  } catch (err) {
    console.error('extract error:', err)
    return res.status(500).json({ error: err.message || 'Internal server error' })
  }
}
